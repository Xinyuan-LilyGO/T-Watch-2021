#pragma once

#include "TWatch_hal.h"

void app_sensor_test(lv_event_t *e);
