#pragma once 

#include "TWatch_hal.h"

#define FACTORY_SSID "xinyuandianzi"
#define FACTORY_PASS "AA15994823428"

void app_wifi_func(lv_event_t *e);