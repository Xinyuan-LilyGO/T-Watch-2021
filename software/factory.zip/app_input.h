#pragma once 

#include "TWatch_hal.h"

void app_io_test(lv_event_t *e);
bool get_app_io_test(void);
void app_send_clicked_event(uint8_t btn);