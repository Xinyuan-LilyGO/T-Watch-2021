#pragma once

#include "TWatch_hal.h"

void app_bluetooth_scan_func(lv_event_t *e);
